# SMKTRON CH4 oficial — 25/10/2026

Promoção autorizada pelo usuário, incluindo Pad Chords, MIX/PAN, nova paleta e otimização sem perdas. Padrão sem SAVE válido: volume de cena 90% (921/1023), Master 70%. SAVE válido e cenas existentes preservados. Versão 0.3.0-ch4; nenhuma alegação de novo teste físico nesta sessão. AP8 preservada em /previous-ap8/ no endereço oficial.

# SMKTRON Pad Chords CH3 — LEDs e fontes compactadas

Versão experimental atual: CH3. As seções CH1/CH2 abaixo documentam a evolução. A AP8 oficial continua intacta.

# SMKTRON Pad Chords CH2 — protótipo privado

Protótipo autorizado em 25/10/2026 por Marcus Padrini. AP8 oficial e seus instaladores permanecem preservados. Sem firmware instalável neste pacote.

- GLOBAL possui uma terceira página PAD CHORDS. K1 MIX (0% só melodia; 100% só acordes; crossfade de potência constante), K2 PAN MELODY, K3 PAN CHORDS (-100 L, 0 CENTER, +100 R), K4 liga/desliga. REC/HOLD/tape permanecem nos pads. Pans balanceados: centro mantém o nível atual, extremo silencia o canal oposto. Botão da página web também liga/desliga.
- Pads 1–8: oito acordes, até seis notas MIDI distintas cada. Último pad substitui o anterior; um acorde de cada vez, mesmo sem HOLD.
- Pad 9 REC: arme, selecione o destino, toque no teclado físico virtual de 37 teclas ou MIDI, solte todas as teclas. Salva automaticamente no banco global. Mais de seis notas cancela a tomada, preservando o acorde anterior e permitindo tentar novamente.
- Pad 10 HOLD: mantém depois de soltar. Outro pad de acorde substitui o anterior; desligar libera. O HOLD do teclado continua separado.
- Pads 11–14: FLUTE, CHOIR, CELLO, VIOLINS, exclusivos dos acordes. Pad 15 STOP/cancelar REC; 16 sair.
- Seis vozes reservadas para teclado, seis para pads. Mesmo pitch entre grupos tem gate e posição de fita independentes. Em modo normal, AP8 mantém 12 vozes e layer. Ao entrar/sair do modo, notas e transportes são liberados.
- Timbre e acordes são globais, separados dos SAVEs e das cenas. HOLD, REC e modo iniciam desligados. Cenas têm precedência: abrir cenas sai de Pad Chords.
- No navegador, banco global versionado no localStorage, comum às recompilações CH1. Flash emulada usa duas cópias com CRC e cabeçalho final. AP8 é a referência B; acordes só existem na build A/CH1. A referência não recebe pads do novo modo enquanto A está selecionado.
- FX, envelope, afinação, volume de cena e Master compartilhados. Pan ocorre antes da cadeia: tape/TONE/EQ têm estados L/R separados; vibrato e Leslie mantêm o sinal direto posicionado e o efeito compartilhado; echo e reverb possuem o mesmo retorno compartilhado. Não existem dois processadores de reverb ou delay. Não são dois processadores completos; os dois grupos reutilizam os samples existentes e o mesmo mixer.

## Build e verificações

`python experiments/chords/build.py` gera um overlay em diretório ignorado e compila CH1 WebAssembly com Zig. A base AP8 em experiments/appearance/engine é copiada sem ser alterada. `python experiments/chords/package.py` gera a interface a partir de templates/lab. `node --test tests/chords.test.mjs` valida motor, storage e AudioWorklet real.

Build nativa usa as ferramentas JieLi e o SDK já documentados na base: `JIELI_TOOLCHAIN=... AC79_SDK=... python experiments/chords/build.py --native`.

Primeira medição: **XIP excede o limite em 2132 bytes**, portanto não há firmware pronto para instalação. Não foi feita gravação nem teste de desempenho no teclado. Endereços propostos do banco nativo: 0xA0000–0xA1FFF, com allowlist e asserts, separados do boot, cenas, owner e regiões protegidas. Ainda precisam de validação física após caber no app. Nenhum novo sample/imagem foi incluído.

## Origem e licenças

Código derivado GPL-3.0-only. Base FMEL-1 de AntonioAltea, port SMK-37 de M. Geisler/genkigenki, Dinghy de zvenson, Felucca de Hügelton Instruments e SLOOP/isod89. Reverb adaptado de OberVave/zvenson, algoritmo Jon Dattorro. Créditos e condições específicas dos samples de Bernie Kornowicz/Taijiguy preservados na página e nos arquivos de origem. Ilustrações Javi e fontes mantêm suas licenças. Ver experiments/appearance/engine e créditos da interface.

## CH2 — Mix e pan globais

A migração lê o registro CH1 v1 de 58 bytes e preserva os oito acordes e o tape. Registro v2: 61 bytes, acrescenta mix e dois pans. Mix inicial 50%, pans CENTER. Os parâmetros são independentes das cenas, persistidos junto ao banco após 600 ms sem alterações para evitar gravação em cada passo do encoder. Falha mantém a cópia anterior e tenta novamente; outra gravação de acorde/tape incorpora os valores atuais. Armazenamento do navegador mantém a chave CH1 para a migração.

Ganhos têm rampas de 20 ms. Mix e pan são aplicados em dois buses de seis vozes, antes do tratamento de fita, TONE e EQ. O caminho normal mono continua idêntico ao AP8 em PCM. Hiss e retornos de efeitos compartilhados podem ocupar os dois canais, mesmo com uma voz toda para um lado. Para avaliar separação do áudio seco, testes removem a componente DC do estágio de drive herdado e usam FX inativos.

## CH3 — LEDs e encaixe nativo

- Pads 1–8 vazios: lilás escuro RGB(18,4,28); gravados: lilás RGB(112,32,176); ativo: rosa RGB(255,48,144). Destino REC pisca rosa claro com a cadência existente de 256 ms por estado.
- Pads 11–14 usam a mesma tabela SMK_PATCH_RGB dos timbres no modo normal: FLUTE verde (0,255,128), CHOIR roxo (176,0,255), CELLO laranja (255,112,0), VIOLINS azul (0,96,255). Selecionado usa nível normal; demais 1/16.
- Presets mantêm a cor base. Último carregado com sucesso fica em verde distinto (R=G/6, B=G/3), com G variando de 160 a 255 em ciclo triangular de 1,8 s, nunca apagando. sc_loaded registra apenas recall válido; salvar outro slot ou tentar carregar um slot vazio não o move. Mantido entre aberturas da tela na mesma sessão; começa sem seleção no boot.
- Continua havendo confirmação breve de gravação e progresso ao segurar o pad. Brilho global aplica-se a todas as cores e animações.
- Fontes de sistema usam a compactação sem perdas validada em experiments/space, agora incorporada ao build. Os 67.392 pixels são verificados em cada compilação. Nenhuma fonte suavizada, sample, algoritmo de áudio, polifonia ou funcionalidade foi removida.
- Build nativa CH3 passou: 615.272 / 619.520 bytes, **4.248 bytes livres**. RAM 29.648 / 98.304; pool 237.860 / 344.064. Sem pacote instalável no Site e sem teste físico.
- 18 testes passaram, incluindo igualdade de PCM CH2/CH3, paleta por tape, brilho 75%, REC rosa e semântica do último preset carregado. A referência B permanece AP8 original; novas luzes são testadas na build A/CH3.

## CH3 — instalador de teste físico

Autorização de teste no teclado dada por Marcus em 25/10/2026. Instalador isolado em `/install/`, sem mudança na versão oficial AP8. SHA-256 do pacote nativo CH3: `eacb6dd6022dbeb7c7bee374ef406a565c47d505d055b3fe17e786bd6acd4495` (651.266 bytes). Modelo exclusivo SMK-37 Pro_453. A versão USB _453 é compartilhada; conferir CH3 na tela. Protocolo, parser de pacote e bloqueios de instalação mantidos do instalador AP8. Exige V016 original validado como arquivo de retorno; nenhuma gravação ocorre ao abrir ou apenas consultar. A AP8 estável permanece acessível por link para retorno ao SMKTRON oficial.

`python experiments/chords/package_installer.py` gera o instalador a partir do template preservado da AP8 e do pacote nativo compilado. Recompilar nativo com `python experiments/chords/build.py --native` usando as ferramentas documentadas. O pacote não foi instalado por esta sessão: o teste físico será feito pelo usuário. O banco de acordes do navegador não é transferido ao instrumento.

## Manual on-line

Manual em `/manual/`, com comportamento atual do SMKTRON apresentado em uma única versão, conforme orientação do usuário para a documentação. Não altera o status de lançamento do firmware. 26 seções, todas as 14 páginas do display, 30 capturas reais em Light/Dark incluindo presets, busca, ampliação, mapas de pads por modo e impressão. Conteúdo em `manual/content.py`, montagem por `tools/build_manual.py`, capturas por `tools/capture_manual.mjs` e conversão RGB565 para PNG sem redesenhar a interface.

As capturas de referência e seus parâmetros/sha de engine estão em `dist/manual/captures.json`. Revisão editorial cruza os controles com o motor C, incluindo limites, dois HOLDs, dois REC, memória global/cenas e polifonia 12 ou 6+6. O manual não acessa MIDI nem altera o instrumento.
