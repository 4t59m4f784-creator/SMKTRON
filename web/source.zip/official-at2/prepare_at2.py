from pathlib import Path
import shutil,json,re,zipfile
R=Path(__file__).resolve().parent;D=R/'dist';C=R.parent/'smktron-chords';L=C/'dist';B=D/'previous-pm1'
if not B.exists():
 B.mkdir()
 for p in list(D.iterdir()):
  if p.name.startswith('previous-'):continue
  if p.is_dir():shutil.copytree(p,B/p.name)
  else:shutil.copy2(p,B/p.name)
 # Keep historical rollback references pointed at sibling snapshots.
 for p in B.rglob('*'):
  if p.is_file() and p.suffix in ['.html','.json','.md']:
   s=p.read_text();s=s.replace('href="previous-','href="../previous-').replace('../previous-ch4/','../../previous-ch4/') if p.parent==B/'install' else s.replace('href="previous-','href="../previous-');p.write_text(s)
shutil.copy2(L/'audio-preview/mel.wasm',D/'mel.wasm')
shutil.rmtree(D/'install');shutil.copytree(L/'install-audio',D/'install')
for n in ['index.html','app.js','worklet.js']:
 p=D/n;p.write_text(p.read_text().replace('0.3.0-pm1','0.3.0-at2').replace('official-pm1','official-at2').replace('SMKTRON-PM1-fontes.zip','SMKTRON-AT2-fontes.zip').replace('SMKTRON · PM1','SMKTRON · AT2'))
for p in (D/'install').iterdir():
 if p.is_file() and p.suffix in ['.html','.json','.md','.js']:
  s=p.read_text().replace('../audio-preview/source.zip','../downloads/SMKTRON-AT2-fontes.zip').replace('../audio-preview/','../').replace('AT2 · TESTE DE ÁUDIO','AT2 · ESTÁVEL E OFICIAL').replace('https://smktron-rf1.padrini.chatgpt.site/previous-ap8/install/','../previous-pm1/install/').replace('AP8 oficial preservada','PM1 anterior preservada').replace('abrir instalador AP8','abrir instalador PM1').replace('A AP8 oficial permanece','A PM1 anterior permanece')
  s=re.sub(r'<b>Teste isolado:.*?</b> ','',s,flags=re.S);p.write_text(s)
p=D/'install/manifest.json';m=json.loads(p.read_text());m.update(status='official-user-authorized',hardware_tested=False,user_approved=True,approval='User approved AT2 on 2026-10-27',official_rollback='../previous-pm1/install/');p.write_text(json.dumps(m,indent=2)+'\n')
shutil.copy2(L/'audio-preview/source.zip',D/'downloads/SMKTRON-AT2-fontes.zip')
for folder in ['manual','tools']:
 (R/folder).mkdir(exist_ok=True)
for n in ['content.py']:shutil.copy2(C/'manual'/n,R/'manual'/n)
for n in ['capture_manual.mjs','convert_manual_images.py','build_manual.py']:shutil.copy2(C/'tools'/n,R/'tools'/n)
p=R/'tools/capture_manual.mjs';p.write_text(p.read_text().replace('dist/pads-preview/mel.wasm','dist/mel.wasm'))
p=R/'tools/build_manual.py';s=p.read_text().replace('Tela real com o acesso aos presets fixado','Favoritos nos pads; o display mostra o Patch ou Layer carregado').replace('Acesso às cenas no display','Patch carregado com Favoritos nos pads').replace('25 de outubro de 2026','27 de outubro de 2026');s=s.replace('<h3>O que a cena guarda</h3>','<p>No modo Favoritos, somente os pads mudam de função. O display mostra PLAY para um patch simples e LAYER quando a cena usa uma camada. A troca usa uma breve redução e retomada do sinal direto para suavizar a transição; o histórico de reverb e eco continua sendo processado.</p><h3>O que a cena guarda</h3>');s=s.replace('../chords-preview/source.zip','../downloads/SMKTRON-AT2-fontes.zip').replace('../chords-preview/','../');p.write_text(s)
p=R/'verify_share.mjs';s=p.read_text().replace('pads-preview','audio-preview').replace('install-pads','install-audio').replace('0.3.0-pm1','0.3.0-at2').replace('0c692fae041479c1ac136d8635a04adc708ad08bc663a3b85a1a8472aecdb540','7d8062754c8b41ceed48045543c23bbee9c618e1202b0ccf9469efdb7fada75b').replace('PM1','AT2');p.write_text(s)
(R/'README.md').write_text('# SMKTRON AT2 oficial\n\nAT2 aprovada pelo usuário em 27/10/2026. Binários idênticos ao protótipo aprovado; melhorias de transição de efeitos e volume, Favoritos nos pads com display Patch/Layer, transição curta de cenas. PM1 preservada em previous-pm1/.\n\nO conteúdo metálico residual de alguns samples com reverb aguarda gravação para análise. Não houve alteração adicional do timbre nesta promoção.\n')
print('AT2 approved bytes prepared; PM1 preserved.')
