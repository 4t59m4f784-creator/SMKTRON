# SMKTRON AT2 oficial

AT2 aprovada pelo usuário em 27/10/2026. Binários idênticos ao protótipo aprovado; melhorias de transição de efeitos e volume, Favoritos nos pads com display Patch/Layer, transição curta de cenas. PM1 preservada em previous-pm1/.

O conteúdo metálico residual de alguns samples com reverb aguarda gravação para análise. Não houve alteração adicional do timbre nesta promoção.
